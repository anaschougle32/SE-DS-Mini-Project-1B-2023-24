from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import CustomUser
from .models import Complaint
from .models import VisitorLog
from .models import Announcement
from .models import Notification

class CustomUserCreationForm(UserCreationForm):
    flat_no = forms.CharField(max_length=10)
    full_name = forms.CharField(max_length=100)
    mobile_no = forms.CharField(max_length=15)

    class Meta:
        model = CustomUser
        fields = ('flat_no', 'full_name', 'mobile_no', 'username', 'email', 'password1', 'password2')

class CustomAuthenticationForm(AuthenticationForm):
    class Meta:
        model = CustomUser
        fields = ('username', 'password')



class ComplaintForm(forms.ModelForm):
    class Meta:
        model = Complaint
        fields = ('subject', 'description')

class VisitorLogForm(forms.ModelForm):
    class Meta:
        model = VisitorLog
        fields = ['visitor_name', 'flat_number', 'purpose']

class AnnouncementForm(forms.ModelForm):
    class Meta:
        model = Announcement
        fields = ['title', 'content']

class PaymentForm(forms.Form):
    payment_id = forms.CharField(widget=forms.HiddenInput())

class NotificationForm(forms.ModelForm):
    class Meta:
        model = Notification
        fields = ['title', 'message']
