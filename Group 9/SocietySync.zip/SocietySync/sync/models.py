from django.contrib.auth.models import AbstractUser
from django.db import models


class CustomUser(AbstractUser):    #creation of customusermodel
    flat_no = models.CharField(max_length=10)
    full_name = models.CharField(max_length=100)
    mobile_no = models.CharField(max_length=15)


  
class ComplaintUser(models.Model):            #complaint database creation
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    subject = models.CharField(max_length=100)
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.subject

class VisitorLog(models.Model):
    visitor_name = models.CharField(max_length=100)  #visitor log database creation
    flat_number = models.CharField(max_length=10)
    purpose = models.TextField()
    visit_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.visitor_name} - {self.flat_number}'
    
class Announcement(models.Model):
    title = models.CharField(max_length=100)  #notice board database creation
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
    
class MaintenanceBill(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)  #maintaince bill database creation
    month = models.DateField()                                       
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    due_date = models.DateField()
    paid = models.BooleanField(default=False)
    payment_id = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return f'{self.user.username} - {self.month}'


class Complaint(models.Model):   #complaint database creation
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    subject = models.CharField(max_length=100)
    description = models.TextField()
    STATUS_CHOICES = (
        ('ongoing', 'Ongoing'),
        ('completed', 'Completed'),
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='ongoing')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.subject


class Notification(models.Model):
    title = models.CharField(max_length=100)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
