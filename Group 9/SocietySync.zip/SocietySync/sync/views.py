from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .forms import CustomUserCreationForm, CustomAuthenticationForm
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required
from .forms import ComplaintForm
from .forms import VisitorLogForm
from .models import VisitorLog
from .models import CustomUser
from django.contrib.auth.decorators import user_passes_test
from django.contrib.admin.views.decorators import staff_member_required
from .forms import AnnouncementForm
from .models import Announcement
from django.conf import settings
from django.urls import reverse
from razorpay import Client as RazorpayClient
from .models import MaintenanceBill
from .forms import PaymentForm
from datetime import datetime, timedelta
from .utils import calculate_bill_amount, DEFAULT_MAINTENANCE_AMOUNT
from datetime import datetime, timedelta
from django.utils import timezone
from decimal import Decimal
from .models import Complaint
from .models import Notification
from .forms import NotificationForm


def complaint_register(request):
    if request.method == 'POST':
        form = ComplaintForm(request.POST)
        if form.is_valid():
            complaint = form.save(commit=False)
            complaint.user = request.user
            complaint.save()
            messages.success(request, 'Complaint registered successfully!')
            return redirect('complaint_list_ongoing')
    else:
        form = ComplaintForm()
    return render(request, 'sync/complaint_register.html', {'form': form})

def complaint_list_ongoing(request):
    complaints = Complaint.objects.filter(user=request.user,status = 'ongoing')
    return render(request, 'sync/complaint_list.html', {'complaints': complaints})

def complaint_list_completed(request):
    complaints = Complaint.objects.filter(user=request.user,status = 'completed')
    return render(request, 'sync/complaint_list.html', {'complaints': complaints})

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Registration successful!')
            return redirect('dashboard')  
    else:
        form = CustomUserCreationForm()
    return render(request, 'sync/register.html', {'form': form})

def user_login(request):
    if request.method == 'POST':
        form = CustomAuthenticationForm(data=request.POST)
        if form.is_valid():
            user = authenticate(request, username=form.cleaned_data['username'], password=form.cleaned_data['password'])
            if user:
                login(request, user)
                messages.success(request, 'Login successful!')
                return redirect('dashboard')  
            else:
                messages.error(request, 'Invalid login credentials')
    else:
        form = CustomAuthenticationForm()
    return render(request, 'sync/login.html', {'form': form})


def admin_login(request):
    if request.method == 'POST':
        form = CustomAuthenticationForm(data=request.POST)
        if form.is_valid():
            user = authenticate(request, username=form.cleaned_data['username'], password=form.cleaned_data['password'])
            if user.is_superuser == True:
                login(request, user)
                messages.success(request, 'Login successful!')
                return redirect('admindashboard')  
            else:
                messages.error(request, 'Invalid login credentials')
    else:
        form = CustomAuthenticationForm()
    return render(request, 'sync/adminlogin.html', {'form': form})


@login_required
def home(request):
    notifications = Notification.objects.all().order_by('-created_at')[:2]
    return render(request, 'sync/home.html',{'notifications': notifications})

def notification(request):
    notifications = Notification.objects.all().order_by('-created_at')[:2]
    return render(request, 'sync/navbar.html',{'notifications': notifications})

def user_logout(request):
    logout(request)
    messages.info(request, 'Logged out successfully!')
    return redirect('home') 

@login_required
def profile_page(request):
     user = request.user
     return render(request, 'sync/profile.html', {'user': user})
  

def admindashboard(request):
    return render(request, 'sync/index.html',)

def index(request):
    return render(request,'sync/home2.html')

def visitor_log(request):
    if request.method == 'POST':
        form = VisitorLogForm(request.POST)
        if form.is_valid():
            visitor = form.save(commit=False)
            visitor.save()
            messages.success(request, 'visitor registered successfully!')
            return redirect('home')
    else:
        form = VisitorLogForm()
    return render(request, 'sync/visitor_log.html', {'form': form})

def visitor_history(request):
     visitors = VisitorLog.objects.filter(flat_number=request.user.flat_no)
     return render(request, 'sync/visitor_history.html', {'visitors': visitors})

@staff_member_required
def admin_panel(request):
    users = CustomUser.objects.filter(is_superuser = False)
    return render(request, 'sync/admindashboard.html', {'users': users})

@user_passes_test(lambda u: u.is_superuser)
def delete_user(request, user_id):
    user = CustomUser.objects.get(id=user_id)
    user.delete()
    return redirect('admindashboard')

@login_required
def admin_profile_page(request):
    user = request.user
    if user.is_superuser == True: 
        return render(request, 'sync/adminprofile.html', {'user': user})
    
def notice_board(request):
    announcements = Announcement.objects.all().order_by('-created_at')[:5]
    return render(request, 'sync/notice_board.html', {'announcements': announcements})

def create_announcement(request):
    if request.method == 'POST':
        form = AnnouncementForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('admindashboard')
    else:
        form = AnnouncementForm()
    return render(request, 'sync/create_announcements.html', {'form': form})

def generate_bill(request):
    today = timezone.now()
    if today.day < 5:
        # If today is before the 5th of the month, redirect to the last month's bill
        last_month = today.replace(day=1) - timedelta(days=1)
        return redirect('bill_detail', year=last_month.year, month=last_month.month)
    
    # Calculate bill amount including dues
    total_amount = calculate_bill_amount(request.user)

    # Create the bill for the current month
    current_month = today.replace(day=1)
    
    # Calculate the payment due date (20th of the current month)
    due_date = current_month.replace(day=20)
    
    bill, created = MaintenanceBill.objects.get_or_create(user=request.user, month=current_month, defaults={'amount': total_amount, 'due_date': due_date})
    
    # If bill is newly created, set the default maintenance amount
    if created:
        bill.amount = DEFAULT_MAINTENANCE_AMOUNT
        bill.save()
    
    return render(request, 'sync/bill.html', {'bill': bill, 'due_date': due_date})


def initiate_payment(request):
    user = request.user
    if request.method == 'POST':
        amount = request.POST.get('amount')
        # Convert the amount to an integer (in paisa)
        amount_in_paisa = int(Decimal(amount) * 100)
        
        client = RazorpayClient(auth=(settings.RAZORPAY_API_KEY, settings.RAZORPAY_API_SECRET))
        payment_data = {
            'amount': amount_in_paisa,  # Use the integer amount
            'currency': 'INR',
            'receipt': 'maintenance',
            'payment_capture': '1'
        }
        response = client.order.create(data=payment_data)
        order_id = response['id']
        return render(request, 'sync/payment.html', {'order_id': order_id, 'amount': amount_in_paisa,'user':user})
    return redirect('generate_bill')

def payment_success(request):
    if request.method == 'POST':
        form = PaymentForm(request.POST)
        if form.is_valid():
            payment_id = form.cleaned_data.get('payment_id')
            # Update payment status in the database
            bill = MaintenanceBill.objects.get(payment_id=payment_id)
            bill.paid = True
            bill.save()
            return render(request, 'sync/payment_success.html')
    return redirect('generate_bill')

def view_complaints(request):
    complaints = Complaint.objects.filter(status='ongoing').order_by('-created_at')[:10]
    return render(request, 'sync/admincomplaints.html', {'complaints': complaints})

def view_complaints_all(request):
    complaints = Complaint.objects.all().order_by('-created_at')
    return render(request, 'sync/allcomplaints.html', {'complaints': complaints})

def mark_as_completed(request, complaint_id):
    complaint = Complaint.objects.get(pk=complaint_id)
    complaint.status = 'completed'
    complaint.save()
    return redirect('view_complaints')

def view_notifications(request):
    notifications = Notification.objects.all().order_by('-created_at')[:2]
    return render(request, 'sync/notifications.html', {'notifications': notifications})

def create_notification(request):
    if request.method == 'POST':
        form = NotificationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('admindashboard')
    else:
        form = NotificationForm()
    return render(request, 'sync/createnotification.html', {'form': form})


@login_required
def join_room(request):
    if request.method == 'POST':
        roomID = request.POST['roomID']
        return redirect("/meeting?roomID=" + roomID)
    return render(request, 'sync/joinroom.html')

@login_required
def videocall(request):
    user = request.user
    return render(request, 'videocall.html', {'name': user.full_name })