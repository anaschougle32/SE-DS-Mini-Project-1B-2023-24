from django.db.models import Sum
from .models import MaintenanceBill

DEFAULT_MAINTENANCE_AMOUNT = 500

def calculate_bill_amount(user):
    # Calculate total dues of the user
    total_dues = MaintenanceBill.objects.filter(user=user, paid=False).aggregate(total_dues=Sum('amount'))['total_dues'] or 0
    
    # Use default maintenance amount if no dues
    if total_dues == 0:
        total_dues = DEFAULT_MAINTENANCE_AMOUNT
    
    return total_dues