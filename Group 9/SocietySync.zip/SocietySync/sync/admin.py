from django.contrib import admin
from .models import Complaint
from .models import Notification

@admin.register(Complaint)
class ComplaintAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'subject', 'status', 'created_at')
    list_filter = ('status',)
    search_fields = ('subject', 'description')
    actions = ['mark_as_ongoing', 'mark_as_completed']

    def mark_as_completed(self, request, queryset):
        queryset.update(status='completed')

    mark_as_completed.short_description = "Mark selected complaints as completed"


class NotificationAdmin(admin.ModelAdmin):
    list_display = ('title', 'created_at')